public class Constants {

    public static final String COLOR_SUCCESS = "32";
    public static final String COLOR_ERROR = "31";
    public static final String COLOR_WARNING = "33";
    public static final String COLOR_INFO = "34";
}
